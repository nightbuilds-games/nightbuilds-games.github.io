HIVE QUEENS - press kit
nightbuilds - https://nightbuilds.app/press.html

One rule, pure logic
One queen bee in every row, every column and every color zone, and never two side by side.
Every grid has a single solution you can reach by pure logic: no lives, no timer, no guessing.

Developer     nightbuilds (Pierre Trochet), France
Genre         Puzzle (logic grid)
Release date  To be announced
Platforms     iPhone (iOS 15 or later). Android version planned.
Price         Free, with ads, no banners. Optional purchases: remove ads ($3.99), remove ads + unlimited hints ($6.99), coin packs ($1.99 and $4.99).
Languages     English, French, Spanish, Portuguese (Brazil)
Age rating    4+
Game page     https://nightbuilds.app/hivequeens/
Contact       see https://nightbuilds.app/press.html

In this folder
  icon-1024.png        app icon
  screenshots-en/      six screenshots, English
  screenshots-fr/      six screenshots, French
  screenshots-es/      six screenshots, Spanish
  screenshots-pt/      six screenshots, Portuguese (Brazil)
  gameplay-clip.mp4    short gameplay clip, no sound
  share-image.jpg      wide image for articles and social posts

Usage
You may use these files, and your own screenshots and footage of the game, in articles, reviews and videos,
including monetized ones. Please credit "Hive Queens" and nightbuilds.

Credits
Design and development: Pierre Trochet.
Music: Kevin MacLeod (incompetech.com), licensed under Creative Commons Attribution 4.0:
"Gymnopedie No. 1" (Satie), "Meditation Impromptu 01", "Meditation Impromptu 02", "Evening Fall (Harp)".
Sound effects: Kenney (kenney.nl).
