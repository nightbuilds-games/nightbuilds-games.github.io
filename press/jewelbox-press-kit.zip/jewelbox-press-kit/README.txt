JEWEL BOX - press kit
nightbuilds - https://nightbuilds.app/press.html

Sort gems, fill every box
Every level is a jewelled object held together by gems. Tap them out in the right order, fill each box
with three of a color, and watch the piece come apart. 300 objects, fifteen worlds, no timer.

Developer     nightbuilds (Pierre Trochet), France
Genre         Puzzle (sorting, take-apart)
Release date  To be announced
Platforms     iPhone (iOS 15 or later). Android version planned.
Price         Free, with ads. Optional purchases: remove ads ($3.99), coin packs ($1.99 and $4.99).
Languages     English, French, Spanish, Portuguese (Brazil)
Age rating    4+
Game page     https://nightbuilds.app/jewelbox/
Contact       see https://nightbuilds.app/press.html

In this folder
  icon-1024.png        app icon
  screenshots-en/      six screenshots, English
  screenshots-fr/      six screenshots, French
  screenshots-es/      six screenshots, Spanish
  screenshots-pt/      six screenshots, Portuguese (Brazil)
  gameplay-clip.mp4    short gameplay clip, no sound
  share-image.jpg      wide image for articles and social posts

Usage
You may use these files, and your own screenshots and footage of the game, in articles, reviews and videos,
including monetized ones. Please credit "Jewel Box" and nightbuilds.

Credits
Design and development: Pierre Trochet.
Music: Kevin MacLeod (incompetech.com), licensed under Creative Commons Attribution 4.0:
"Aquarium" (Saint-Saens), "Dance of the Sugar Plum Fairy" (Tchaikovsky), "Frost Waltz", "Fairytale Waltz", "Music Box Theme",
"Garden Music", "Enchanted Valley", "Enchanted Journey", "Dreamy Flashback", "Atlantean Twilight".
Sound effects: Kenney (kenney.nl).
