JELLIES ON THE RUN - press kit
nightbuilds - https://nightbuilds.app/press.html

Slide, sort, beat the heat!
The sun is out and the jellies are melting! Slide each one to the gate of its color before it's too late.
Quick, cute, and trickier than it looks.

Developer     nightbuilds (Pierre Trochet), France
Genre         Puzzle (sliding blocks)
Release date  October 12, 2026
Platforms     iPhone (iOS 15 or later). Android version planned.
Price         Free, with ads. Optional purchases: remove ads ($3.99), coin packs ($1.99 and $4.99).
Languages     English, French
Age rating    4+
Game page     https://nightbuilds.app/jellies/
Contact       see https://nightbuilds.app/press.html

In this folder
  icon-1024.png        app icon
  screenshots-en/      six screenshots, English
  screenshots-fr/      six screenshots, French
  gameplay-clip.mp4    short gameplay clip, no sound
  share-image.jpg      wide image for articles and social posts

Usage
You may use these files, and your own screenshots and footage of the game, in articles, reviews and videos,
including monetized ones. Please credit "Jellies on the Run" and nightbuilds.

Credits
Design and development: Pierre Trochet.
Music: Kevin MacLeod (incompetech.com), licensed under Creative Commons Attribution 4.0.
Sound effects: Kenney (kenney.nl).
